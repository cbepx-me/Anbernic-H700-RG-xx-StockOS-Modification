#!/bin/sh

#HOME is different:~ -> /root or /
#ROOT_DIR=~/.config/retroarch
ROOT_DIR=/.config/retroarch
RETRO_DIR=/mnt/vendor/deep/retro

DEEP_INPUT_CFG=$RETRO_DIR/ANBERNIC-keys.cfg
RA_ORI_CFG=$RETRO_DIR/retroarch.cfg
RA_Run_BIN=$RETRO_DIR/retroarch

RATMPCONF=$ROOT_DIR/retroarch.cfg

check_rootdir()
{
if [ ! -d $ROOT_DIR ]; then
	mkdir -p $ROOT_DIR
fi
}

reset_cfg() 
{
	check_rootdir

	# user maybe change key or retroarch cfg errr
	# reset retroarch.cfg and key
	rm -rf $ROOT_DIR/retroarch*.cfg
	cp $RA_ORI_CFG       $ROOT_DIR/retroarch.cfg
	cp $DEEP_INPUT_CFG   $RETRO_DIR/autoconfig/udev
}

run_retroarch() 
{
	check_rootdir

	if [ ! -f $ROOT_DIR/retroarch.cfg ]; then
		cp $RA_ORI_CFG    $ROOT_DIR/retroarch.cfg
	fi

	$RA_Run_BIN -c $ROOT_DIR/retroarch.cfg
}

set_ra_language()
{
if [ x$1 != x ]; 
then

	check_rootdir
	
	sed -i 's/\(user_language\).*/user_language = "'$1'"/'  $RATMPCONF
	sync
fi
}

set_ra_snd_card()
{	   
	check_rootdir
	
	sed -i 's/\(audio_device\).*/audio_device = "'$1'"/'  $RATMPCONF
	sync
}

set_ra_volume_db()
{
	check_rootdir
	
	sed -i 's/\(audio_volume\).*/audio_volume = "'$1'"/'  $RATMPCONF
	sync
}

set_ra_game_menu_easy()
{	   
	check_rootdir
	
	sed -i 's/\(menu_show_latency\).*/menu_show_latency = "false"/'    $RATMPCONF
	sed -i 's/\(menu_show_overlays\).*/menu_show_overlays = "false"/'  $RATMPCONF
	sed -i 's/\(menu_show_rewind\).*/menu_show_rewind = "false"/'      $RATMPCONF
	sed -i 's/\(menu_show_video_layout\).*/menu_show_video_layout = "false"/'  $RATMPCONF
#	sed -i 's/\(quick_menu_show_cheats\).*/quick_menu_show_cheats = "false"/'  $RATMPCONF
	
#	sed -i 's/\(quick_menu_show_controls\).*/quick_menu_show_controls = "false"/' $RATMPCONF
#	sed -i 's/\(quick_menu_show_options\).*/quick_menu_show_options = "false"/'   $RATMPCONF
	
	sed -i 's/\(quick_menu_show_reset_core_association\).*/quick_menu_show_reset_core_association = "false"/'  $RATMPCONF
	sed -i 's/\(quick_menu_show_save_core_overrides\).*/quick_menu_show_save_core_overrides = "false"/'   $RATMPCONF
	sed -i 's/\(quick_menu_show_save_game_overrides\).*/quick_menu_show_save_game_overrides = "false"/'   $RATMPCONF
	sed -i 's/\(quick_menu_show_set_core_association\).*/quick_menu_show_set_core_association = "false"/' $RATMPCONF
	sed -i 's/\(quick_menu_show_shaders\).*/quick_menu_show_shaders = "false"/'  $RATMPCONF

	sync
}

set_ra_game_menu_advance()
{	   
	check_rootdir
	
	sed -i 's/\(menu_show_latency\).*/menu_show_latency = "true"/'    $RATMPCONF
	sed -i 's/\(menu_show_overlays\).*/menu_show_overlays = "true"/'  $RATMPCONF
	sed -i 's/\(menu_show_rewind\).*/menu_show_rewind = "true"/'      $RATMPCONF
	sed -i 's/\(menu_show_video_layout\).*/menu_show_video_layout = "true"/'  $RATMPCONF
#	sed -i 's/\(quick_menu_show_cheats\).*/quick_menu_show_cheats = "true"/'  $RATMPCONF
	
#	sed -i 's/\(quick_menu_show_controls\).*/quick_menu_show_controls = "true"/' $RATMPCONF
#	sed -i 's/\(quick_menu_show_options\).*/quick_menu_show_options = "true"/'   $RATMPCONF
	
	sed -i 's/\(quick_menu_show_reset_core_association\).*/quick_menu_show_reset_core_association = "true"/'  $RATMPCONF
	sed -i 's/\(quick_menu_show_save_core_overrides\).*/quick_menu_show_save_core_overrides = "true"/'   $RATMPCONF
	sed -i 's/\(quick_menu_show_save_game_overrides\).*/quick_menu_show_save_game_overrides = "true"/'   $RATMPCONF
	sed -i 's/\(quick_menu_show_set_core_association\).*/quick_menu_show_set_core_association = "true"/' $RATMPCONF	
	sed -i 's/\(quick_menu_show_shaders\).*/quick_menu_show_shaders = "true"/'  $RATMPCONF
	
	sync
}

case "$1" in
  run)
		run_retroarch
		;;
  rest)
		echo "reset retroarch(key) cfg"
		reset_cfg
        ;;
  language)
		set_ra_language $2
		/mnt/mod/ctrl/sw $2
		;;
  snd_card)
		set_ra_snd_card $2
		;;
  volume)
		set_ra_volume_db $2
		;;
  easy)
		set_ra_game_menu_easy
		;;
  adv)
		set_ra_game_menu_advance
		;;
esac
